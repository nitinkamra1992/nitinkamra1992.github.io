import matplotlib.pyplot as plt
import numpy as np
import random

from graph_generation import SBM_graph
from utils import graph_util

def _resample_egde_for_node(sbm_graph, node_id):
    if sbm_graph._graph is None:
        sbm_graph.sample_graph()
    else:
        n = sbm_graph._node_num
        for i in xrange(n):
            if i == node_id:
                continue
            if sbm_graph._graph.has_edge(node_id, i):
                sbm_graph._graph.remove_edge(node_id, i)
                sbm_graph._graph.remove_edge(i, node_id)
            prob = sbm_graph._B[sbm_graph._node_community[node_id], sbm_graph._node_community[i]]
            if np.random.uniform() <= prob:
                sbm_graph._graph.add_edge(node_id, i)
                sbm_graph._graph.add_edge(i, node_id)

def random_node_perturbation(sbm_graph, nodes_to_purturb):
    n = sbm_graph._node_num
    perturb_nodes = random.sample(range(n), nodes_to_purturb)
    for node_id in perturb_nodes:
        new_community = sbm_graph._node_community[node_id]
        while new_community == sbm_graph._node_community[node_id]:
            new_community = random.sample(range(sbm_graph._community_num), 1)[0]
        print 'Node %d change from community %d to %d' % (node_id, sbm_graph._node_community[node_id], new_community)
        sbm_graph._node_community[node_id] = new_community
    for node_id in perturb_nodes:
        _resample_egde_for_node(sbm_graph, node_id)
    return perturb_nodes

def dimnish_community(sbm_graph, community_id, nodes_to_purturb):
    n = sbm_graph._node_num
    community_nodes = [i for i in xrange(n) if sbm_graph._node_community[i] == community_id]
    nodes_to_purturb = min(len(community_nodes), nodes_to_purturb)
    perturb_nodes = random.sample(community_nodes, nodes_to_purturb)
    left_communitis = [i for i in xrange(sbm_graph._community_num) if i != community_id]
    for node_id in perturb_nodes:
        new_community = random.sample(left_communitis, 1)[0]
        print 'Node %d change from community %d to %d' % (node_id, sbm_graph._node_community[node_id], new_community)
        sbm_graph._node_community[node_id] = new_community
    for node_id in perturb_nodes:
        _resample_egde_for_node(sbm_graph, node_id)

    return perturb_nodes


def get_random_perturbation_series(node_num, community_num, length, nodes_to_purturb):
    my_graph = SBM_graph.SBMGraph(node_num, community_num)
    my_graph.sample_graph()

    graphs = [my_graph._graph.copy()]
    nodes_comunities = [my_graph._node_community[:]]
    perturbations = [[]]

    for i in xrange(length - 1):
        print 'Step %d' % i
        perturb_nodes = random_node_perturbation(my_graph, nodes_to_purturb)
        graphs.append(my_graph._graph.copy())
        nodes_comunities.append(my_graph._node_community[:])
        perturbations.append(perturb_nodes)

    return zip(graphs, nodes_comunities, perturbations)

def get_community_diminish_series(node_num, community_num, length, community_id, nodes_to_purturb):
    my_graph = SBM_graph.SBMGraph(node_num, community_num)
    my_graph.sample_graph()

    graphs = [my_graph._graph.copy()]
    nodes_comunities = [my_graph._node_community[:]]
    perturbations = [[]]

    for i in xrange(length - 1):
        print 'Step %d' % i
        perturb_nodes = dimnish_community(my_graph, community_id, nodes_to_purturb)
        graphs.append(my_graph._graph.copy())
        nodes_comunities.append(my_graph._node_community[:])
        perturbations.append(perturb_nodes)

    return zip(graphs, nodes_comunities, perturbations)

if __name__ == '__main__':
    node_num = 256
    community_num = 3
    node_change_num = 10
    length = 10

    prefix = 'data/synthetic/dynamic_SBM/node_pertuabtion_%d_%d_%d' % (node_num, community_num, node_change_num)
    dynamic_sbm_series = get_random_perturbation_series(node_num, community_num, length, node_change_num)
    graph_util.saveDynamicSBmGraph(prefix, dynamic_sbm_series)

    prefix = 'data/synthetic/dynamic_SBM/community_diminish_%d_%d_%d' % (node_num, community_num, node_change_num)
    dynamic_sbm_series = get_community_diminish_series(node_num, community_num, length, 1, node_change_num)
    graph_util.saveDynamicSBmGraph(prefix, dynamic_sbm_series)

