import cPickle as pickle
import matplotlib.pyplot as plt
import numpy as np
import networkx as nx

# from utils import graph_util

class SBMGraph(object):
    def __init__(self, node_num, community_num, inblock_prob=0.1, crossblock_prob=0.01, community_size=None):
        self._node_num = node_num
        self._community_num = community_num
        self._graph = None
        self.set_mtx_B(inblock_prob, crossblock_prob)
        self.sample_node_community(community_size)

    def set_mtx_B(self, inblock_prob=0.1, crossblock_prob=0.01):
        self._B = np.ones((self._community_num, self._community_num)) * crossblock_prob
        for i in xrange(self._community_num):
            self._B[i, i] = inblock_prob
        return self._B

    def sample_node_community(self, community_size=None):
        if community_size is None:
            community_size = np.random.multinomial(self._node_num, [1.0 / self._community_num] * self._community_num)

        self._node_community = []
        assert(len(community_size) == self._community_num)
        for i, size in enumerate(community_size):
            self._node_community += [i] * size

    def sample_graph(self):
        self._graph = nx.DiGraph()
        # add nodes
        self._graph.add_nodes_from(range(self._node_num))
        # add edges
        for i in xrange(self._node_num):
            for j in xrange(i):
                prob = self._B[self._node_community[i], self._node_community[j]]
                if np.random.uniform() <= prob:
                    self._graph.add_edge(i, j)
                    self._graph.add_edge(j, i)
        return self._graph


if __name__ == '__main__':
    settings = [(128, 3), (256, 3), (512, 4), (1024, 5)]
    for (node_num, community_num) in settings:
        my_graph = SBMGraph(node_num, community_num)
        my_graph.sample_graph()
        # save graph
        file_name = "data/synthetic/static_SBM/SBM_%d_%d_graph.gpickle" % (node_num, community_num)
        nx.write_gpickle(my_graph._graph, file_name)
        file_name = "data/synthetic/static_SBM/SBM_%d_%d_node.pkl" % (node_num, community_num)
        with open(file_name, 'wb') as fp:
            pickle.dump(my_graph._node_community, fp)

    # test load
    file_name = "data/synthetic/static_SBM/SBM_%d_%d_graph.gpickle" % (1024, 5)
    G = nx.read_gpickle(file_name)
    # plt.matshow(graph_util.transform_DiGraph_to_adj(G))
    # plt.show()