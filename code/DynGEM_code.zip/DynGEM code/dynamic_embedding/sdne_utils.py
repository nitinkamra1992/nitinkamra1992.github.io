import numpy as np

from keras.layers import Input, Dense
from keras.models import Model, model_from_json
import keras.regularizers as Reg

import pdb

def get_encoder(node_num, d, K, n_units, nu1, nu2, activation_fn):
	# Input
	x = Input(shape=(node_num,))
	# Encoder layers
	y = [None]*(K+1)
	y[0] = x # y[0] is assigned the input, but there are K other actual hidden layers.
	for i in range(K - 1):
		y[i+1] = Dense(n_units[i], activation=activation_fn, W_regularizer=Reg.l1_l2(l1=nu1, l2=nu2))(y[i])
	y[K] = Dense(d, activation=activation_fn, W_regularizer=Reg.l1_l2(l1=nu1, l2=nu2))(y[K - 1]) # K-th hidden layer is also the embedding layer
	# Encoder model
	encoder = Model(input=x, output=y[K])
	return encoder

def get_decoder(node_num, d, K, n_units, nu1, nu2, activation_fn):
	# Input
	y = Input(shape=(d,))
	# Decoder layers
	y_hat = [None]*(K+1)
	y_hat[K] = y # decoder's K+1-th layer is also its input (and also the embedding)
	for i in range(K - 1, 0, -1):
		y_hat[i] = Dense(n_units[i-1], activation=activation_fn, W_regularizer=Reg.l1_l2(l1=nu1, l2=nu2))(y_hat[i+1])
	y_hat[0] = Dense(node_num, activation=activation_fn, W_regularizer=Reg.l1_l2(l1=nu1, l2=nu2))(y_hat[1]) 
	# Output
	x_hat = y_hat[0] # decoder's output is also the actual output
	# Decoder Model
	decoder = Model(input=y, output=x_hat)
	return decoder

def get_autoencoder(encoder, decoder):
	# Input
	x = Input(shape=(encoder.layers[0].input_shape[1],))
	# Generate embedding
	y = encoder(x)
	# Generate reconstruction
	x_hat = decoder(y)
	# Autoencoder Model
	autoencoder = Model(input=x, output=[x_hat, y])
	return autoencoder

def widernet(w1, b1, w2, new_width, old_width, init='net2wider'):
	'''Get initial weights for a wider fully connected (dense) layer with a bigger nout
	# Args
		w1: `weight` of fc layer to become wider, of shape (nin1, nout1)
		b1: `bias` of fc layer to become wider, of shape (nout1,)
		w2: `weight` of next connected fc layer, of shape (nin2, nout2)
		new_width: new `nout` for the wider fc layer 
		init: initialization algorithm for new weights ('random-pad' or 'net2wider')
	'''
	if (w1 is not None and w2 is not None):
		assert w1.shape[1] == w2.shape[0], ('successive layers from original model should have compatible shapes')
	if (w1 is not None and b1 is not None):
		assert w1.shape[1] == b1.shape[0], ('weight and bias from same layer should have compatible shapes')
	if w1 is not None:
		assert new_width > w1.shape[1], ('new width (nout) should be bigger than the existing one')
		assert old_width == w1.shape[1], ('old width should match dimensions of existing layer')

	n = new_width - old_width
	if init == 'random-pad':
		new_w1 = np.random.normal(0, 0.001, size=(w1.shape[0], n)) if w1 is not None else None
		new_b1 = np.ones(n) * 0.001 if b1 is not None else None
		new_w2 = np.random.normal(0, 0.001, size=(n, w2.shape[1])) if w2 is not None else None
	elif init == 'net2wider':
		index = np.random.randint(old_width, size=n)
		factors = np.bincount(index)[index] + 1.
		new_w1 = w1[:, index] if w1 is not None else None
		new_b1 = b1[index] if b1 is not None else None
		new_w2 = w2[index, :] / factors[:, np.newaxis] if w2 is not None else None
	else:
		raise ValueError('Unsupported weight initializer: %s' % init)

	final_w1 = np.concatenate((w1, new_w1), axis=1) if w1 is not None else None
	final_b1 = np.concatenate((b1, new_b1), axis=0) if b1 is not None else None
	if w2 is not None:
		if init == 'random-pad':
			final_w2 = np.concatenate((w2, new_w2), axis=0) if w2 is not None else None
		elif init == 'net2wider':
			# add small noise to break symmetry
			noise = np.random.normal(0, 1e-3 * new_w2.std(), size=new_w2.shape)
			final_w2 = np.concatenate((w2, new_w2 + noise), axis=0)
			final_w2[index, :] = new_w2
		else:
			raise ValueError('Unsupported weight initializer: %s' % init)
	else:
		final_w2 = None	

	return final_w1, final_b1, final_w2

def deepernet(n0, n1, n2, w, b):
	'''Get weights for a newly added fc layer'.
	# Args
		n0: size of previous layer
		n1: size of newly added layer
		n2: size of next layer
		w: previous weights between previous layer and next layer
		b: previous biases of next layer
	# Returns
		w1: new weights of new layer
		w2: new weights of next layer
		b1: new biases of new layer
		b2: new biases of next layer
	'''
	assert w.shape == (n0,n2), ('layer from original model should have compatible shape')
	assert b.shape == (n2,), ('weight and bias from same layer should have compatible shapes')
	b1 = np.zeros(n1)
	b2 = np.copy(b)
	w1 = 0.01 * np.random.randn(n0,n1)
	w2 = 0.01 * np.random.randn(n1,n2)
	alpha = 0.01
	t = 0
	while ((t < 2000) and (np.linalg.norm(w - np.dot(w1, w2)) >= 0.01)):
		w1_temp = np.copy(w1)
		w2_temp = np.copy(w2)
		# Gradient Update
		w1_temp -= alpha * np.dot(np.dot(w1, w2) - w, w2.T)
		w2_temp -= alpha * np.dot(w1.T, np.dot(w1, w2) - w)
		# Projection and assignment
		w1 = w1_temp.clip(min=0)
		w2 = w2_temp
		# Alpha decay
		alpha *= 0.9995
		t += 1
	return w1, w2, b1, b2

def get_new_model_shape(n_units_prev, new_node_num, rho, deepen=False):
	assert new_node_num > n_units_prev[0], ('Error: No layer expansion needed')
	n_units = n_units_prev[:]
	n_units[0] = new_node_num
	
	layer_num = len(n_units)
	i = 1
	while(i < layer_num):
		if(n_units[i] >= n_units[i-1] * rho):
			i += 1
		else:
			if(i == layer_num - 1):
				if deepen:
					# Deepening
					new_n_units = n_units[:i]
					new_n_units.extend([int(rho * n_units[i-1] / 2 + n_units[i] / (2 * rho)), n_units[i]])
					n_units = new_n_units
					layer_num = len(n_units)
				else:
					i += 1
			else:
				# Widening
				n_units[i] = int((1 + rho) * n_units[i-1] / 2)
				i += 1
	return n_units

def graphify(reconstruction):
	[n1,n2] = reconstruction.shape
	n = min(n1,n2)
	reconstruction = np.copy(reconstruction[0:n, 0:n])
	reconstruction = (reconstruction + reconstruction.T)/2
	reconstruction -= np.diag(np.diag(reconstruction))
	return reconstruction

def loadmodel(filename):
	try:
		model = model_from_json(open(filename).read())
	except:
		print('Error reading file: {0}. Cannot load previous model'.format(filename))
		exit()
	return model

def loadweights(model, filename):
	try:
		model.load_weights(filename)
	except:
		print('Error reading file: {0}. Cannot load previous weights'.format(filename))
		exit()

def savemodel(model, filename):
	json_string = model.to_json()
	open(filename, 'w').write(json_string)

def saveweights(model, filename):
	model.save_weights(filename, overwrite=True)