import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import scipy.io as sio

import sys
sys.path.append('./')

from static_graph_embedding import StaticGraphEmbedding
from utils import graph_util
from utils import plot_util
from visualization import plot_static_embedding

class LaplacianEigenmaps(StaticGraphEmbedding):

	def __init__(self, d):
		self._d = d
		self._method_name = 'lap_eigmap_svd'
		self._X = None

	def get_method_name(self):
		return self._method_name

	def get_method_summary(self):
		return '%s_%d' % (self._method_name, self._d)

	def learn_embedding(self, graph):
		A = graph_util.transform_DiGraph_to_adj(graph)
		if not np.allclose(A.T, A):
			print "laplace eigmap approach only works for symmetric graphs!"
			return

		self._node_num = A.shape[0]

		D = np.diag(np.sum(A, 1))
		L_G = D - A
		zeroRows = np.where(D.sum(1)==0)
		D[zeroRows, zeroRows] = np.inf
		d_min_half = np.linalg.inv(np.sqrt(D))
		L_sym = np.dot(d_min_half, np.dot(L_G, d_min_half))

		w, v = np.linalg.eigh(L_sym)
		w = np.diag(w)

		self._X = v[:, 1:self._d + 1]

		p_d_p_t = np.dot(v, np.dot(w, v.T))
		eig_err = np.linalg.norm(p_d_p_t - L_sym)
		print 'Laplacian reconstruction error (full rank): %f' % eig_err

		p_d_p_t = np.dot(self._X, np.dot(w[1:self._d+1, 1:self._d+1], self._X.T))
		eig_err = np.linalg.norm(p_d_p_t - L_sym)
		print 'Laplacian reconstruction error (low rank approx): %f' % eig_err

		return self._X

	def get_embedding(self):
		return self._X

	def get_edge_weight(self, i, j):
		return np.exp(-np.power(np.linalg.norm(self._X[i, :] - self._X[j, :]), 2))

	def get_reconstructed_adj(self):
		adj_mtx_r = np.zeros((self._node_num, self._node_num))
		for v_i in range(self._node_num):
			for v_j in range(self._node_num):
				if v_i == v_j:
					continue
				adj_mtx_r[v_i, v_j] = self.get_edge_weight(v_i, v_j)
		return adj_mtx_r

if __name__ == '__main__':
	# load synthetic graph
	file_prefix = "data/synthetic/static_SBM/SBM_%d_%d" % (256, 3)
	G, node_community = graph_util.loadSBMGraph(file_prefix)
	node_colors = plot_util.get_node_color(node_community)

	static_embedding = LaplacianEigenmaps(2)
	static_embedding.learn_embedding(G)

	plot_static_embedding.plot_static_embedding2D(static_embedding.get_embedding(), di_graph=G, node_colors=node_colors)
	plt.show()

