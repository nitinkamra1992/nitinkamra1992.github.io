import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import scipy.io as sio

import sys
sys.path.append('./')

from static_graph_embedding import StaticGraphEmbedding
from utils import graph_util
from utils import plot_util
from visualization import plot_static_embedding

from keras.layers import Input, Dense, Lambda, merge
from keras.models import Model
import keras.regularizers as Reg
from keras.optimizers import SGD
from keras import backend as KBack

from theano.printing import debugprint as dbprint, pprint
import pdb

class SDNE(StaticGraphEmbedding):

	def __init__(self, d, beta, alpha, nu, K, n_units, n_iter, xeta, n_batch):
		''' Initialize the SDNE class

		Args:
			d: dimension of the embedding
			beta: penalty parameter in matrix B of 2nd order objective
			alpha: weighing hyperparameter for 1st order objective
			nu: regularization hyperparameter			
			K: number of hidden layers in encoder/decoder
			n_units: vector of length K-1 containing #units in hidden layers of encoder/decoder, not including the units in the embedding layer
			n_iter: number of sgd iterations
			xeta: sgd step size parameter
			n_batch: minibatch size for SGD
		'''
		self._method_name = 'sdne' # embedding method name
		self._d = d	# embedding dimension
		self._Y = None # embedding
		self._beta = beta
		self._alpha = alpha
		self._nu = nu		
		self._K = K
		self._n_units = n_units
		self._n_iter = n_iter
		self._xeta = xeta
		self._n_batch = n_batch
		self._num_iter = n_iter # max number of iterations during sgd (variable)		
		# self._node_num is number of nodes: initialized later in learn_embedding()
		# self._autoencoder is the vertex->embedding model
		# self._model is the SDNE model to be trained (uses self._autoencoder internally)
		# self._S_hat is the reconstructed adjacency matrix

	def get_method_name(self):
		return self._method_name

	def get_method_summary(self):
		return '%s_%d' % (self._method_name, self._d)

	def learn_embedding(self, graph):
		S = graph_util.transform_DiGraph_to_adj(graph)
		if not np.allclose(S.T, S):
			print "SDNE only works for symmetric graphs! Making the graph symmetric"
		S = (S + S.T)/2					# enforce S is symmetric
		self._node_num = S.shape[0]		
		n_edges = np.count_nonzero(S)/2 # assuming diag(S) = 0
		# Create matrix B
		B = np.ones(S.shape)
		B[S != 0] = self._beta

		# compute degree of each node
		deg = np.sum(S!=0, 1)

		# Structure data in the correct format for the SDNE model
		# InData format: [x1, x2]
		# OutData format: [b1, b2, s12, deg1, deg2]
		InData = np.zeros((n_edges, 2*self._node_num))
		OutData = np.zeros((n_edges, 2*self._node_num + 3))
		e = 0
		for i in range(self._node_num):
			for j in range(i+1, self._node_num):
				if(S[i][j] != 0):
					temp = np.append(S[i,:], S[j,:])
					InData[e,:] = temp
					temp = np.append(np.append(np.append(np.append(B[i,:], B[j,:]), S[i,j]), deg[i]), deg[j])
					OutData[e,:] = temp
					e += 1

		# Initialize self._autoencoder
		# NOTE: We use ReLu activations instead of sigmoid (in paper), to avert vanishing gradients and have faster training
		# Input
		x = Input(shape=(self._node_num,))
		# Encoder layers
		y = [None]*(self._K+1)
		y[0] = x # y[0] is assigned the input, but there are K other actual hidden layers.
		for i in range(self._K - 1):
			y[i+1] = Dense(self._n_units[i], activation='relu', W_regularizer=Reg.l2(l=self._nu))(y[i])
		y[self._K] = Dense(self._d, activation='relu', W_regularizer=Reg.l2(l=self._nu))(y[self._K - 1]) # K-th hidden layer is also the embedding layer
		# Decoder layers
		y_hat = [None]*(self._K+1)
		y_hat[self._K] = y[self._K] # decoder's input layer is encoder's output layer (embedding layer)
		for i in range(self._K - 1, 0, -1):
			y_hat[i] = Dense(self._n_units[i-1], activation='relu', W_regularizer=Reg.l2(l=self._nu))(y_hat[i+1])
		y_hat[0] = Dense(self._node_num, activation='relu', W_regularizer=Reg.l2(l=self._nu))(y_hat[1]) 
		# Output
		x_hat = y_hat[0] # decoder's output is also the actual output
		# Model
		self._autoencoder = Model(input=x, output=[x_hat, y[self._K]])

		# Initialize self._model
		# Input	
		x_in = Input(shape=(2*self._node_num,), name='x_in')
		x1 = Lambda(lambda x: x[:,0:self._node_num], output_shape=(self._node_num,))(x_in)
		x2 = Lambda(lambda x: x[:,self._node_num:2*self._node_num], output_shape=(self._node_num,))(x_in)
		# Process inputs
		[x_hat1, y1] = self._autoencoder(x1)
		[x_hat2, y2] = self._autoencoder(x2)
		# Outputs
		x_diff1 = merge([x_hat1, x1], mode=lambda (a,b): a - b, output_shape=lambda L: L[1])
		x_diff2 = merge([x_hat2, x2], mode=lambda (a,b): a - b, output_shape=lambda L: L[1])
		y_diff = merge([y2, y1], mode=lambda (a,b): a - b, output_shape=lambda L: L[1])

		# Objectives
		def weighted_mse_x(y_true, y_pred):
			''' Hack: This fn doesn't accept additional arguments. We use y_true to pass them.
				y_pred: Contains x_hat - x
				y_true: Contains [b, deg]
			'''			
			return KBack.sum(KBack.square(y_pred * y_true[:,0:self._node_num]), axis=-1)/y_true[:,self._node_num]
		def weighted_mse_y(y_true, y_pred):
			''' Hack: This fn doesn't accept additional arguments. We use y_true to pass them.
				y_pred: Contains y2 - y1
				y_true: Contains s12
			'''			
			min_batch_size = y_true.shape[0]
			return KBack.sum(KBack.square(y_pred), axis=-1).reshape([min_batch_size, 1]) * y_true
		
		# Model
		self._model = Model(input=x_in, output=[x_diff1, x_diff2, y_diff])
		sgd = SGD(lr=self._xeta, decay=1e-5, momentum=0.99, nesterov=True)		
		self._model.compile(optimizer=sgd, loss=[weighted_mse_x, weighted_mse_x, weighted_mse_y], loss_weights=[1, 1, self._alpha])

		# Train the model		
		self._model.fit(InData, [ np.append(OutData[:,0:self._node_num], np.reshape(OutData[:,2*self._node_num+1], [n_edges, 1]), axis=1), 
			np.append(OutData[:,self._node_num:2*self._node_num], np.reshape(OutData[:,2*self._node_num+2], [n_edges, 1]), axis=1), 
			OutData[:,2*self._node_num] ], nb_epoch=self._num_iter, batch_size=self._n_batch, shuffle=True, verbose=1)

		# Get embedding for all points and return it
		[self._S_hat, self._Y] = self._autoencoder.predict(S, batch_size=self._n_batch)
		# pdb.set_trace()
		return self._Y

	def get_embedding(self):
		return self._Y

	def predict_edge_weight(self, i, j):
		return (self._S_hat[i,j] + self._S_hat[j,i])/2

	def reconstruct_graph(self):
		'''Construct the graph from the learnt embedding

		Returns:
		    A numpy array containing the reconstructed graph.
		'''
		adj_mtx_r = np.zeros((self._node_num, self._node_num)) # G_r is the reconstructed graph
		for v_i in range(self._node_num):
			for v_j in range(self._node_num):
				if v_i == v_j:
					continue
				adj_mtx_r[v_i, v_j] = self.predict_edge_weight(v_i, v_j)
		return adj_mtx_r

if __name__ == '__main__':
	# load synthetic graph
	file_prefix = "data/synthetic/static_SBM/SBM_%d_%d" % (1024, 5)
	G, node_community = graph_util.loadSBMGraph(file_prefix)
	node_colors = plot_util.get_node_color(node_community)

	static_embedding = SDNE(100, 5, 0.001, 1e-5, 3, [500, 300,], 30, 0.01, 500)
	static_embedding.learn_embedding(G)

	plot_static_embedding.plot_static_embedding2D(static_embedding.get_embedding(), di_graph=G, node_colors=node_colors)
	plt.show()