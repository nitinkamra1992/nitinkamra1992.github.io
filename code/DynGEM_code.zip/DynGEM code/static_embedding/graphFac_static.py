import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import scipy.io as sio

import sys
sys.path.append('./')

from static_graph_embedding import StaticGraphEmbedding
from utils import graph_util
from utils import plot_util
from visualization import plot_static_embedding
		
		
class GraphFactorization(StaticGraphEmbedding):

	def __init__(self, d, max_iter, eta, regu):
		''' Initialize the GraphFactorization class

		Args:
			d: dimension of the embedding
			eta: learning rate of sgd
			regu: regularization coefficient of magnitude of weights
			max_iter: max iterations in sgd
		'''
		self._d = d
		self._eta = eta
		self._regu = regu
		self._max_iter = max_iter
		self._method_name = 'graph_factor_sgd'

	def get_method_name(self):
		return self._method_name

	def get_method_summary(self):
		return '%s_%d' % (self._method_name, self._d)

	def learn_embedding(self, graph):
		A = graph_util.transform_DiGraph_to_adj(graph)
		if not np.allclose(A.T, A):
			print "laplace eigmap approach only works for symmetric graphs!"
			return

		self._node_num = A.shape[0]
		edgeList = np.where(A > 0)

		self._X = 0.01*np.random.randn(self._node_num, self._d)
		for iter_id in range(self._max_iter):
			for i, j in zip(edgeList[0], edgeList[1]):
				if j >= i:
					continue
				delPhi = -(A[i, j] - np.dot(self._X[i, :], self._X[j, :]))*self._X[j, :] + self._regu*self._X[i, :]
				self._X[i, :] -= self._eta*delPhi

		return self._X

	def get_embedding(self):
		return self._X

	def get_edge_weight(self, i, j):
		return np.dot(self._X[i, :], self._X[j, :])

	def get_reconstructed_adj(self):
		adj_mtx_r = np.zeros((self._node_num, self._node_num)) # G_r is the reconstructed graph
		for v_i in range(self._node_num):
			for v_j in range(self._node_num):
				if v_i == v_j:
					continue
				adj_mtx_r[v_i, v_j] = self.get_edge_weight(v_i, v_j)
		return adj_mtx_r

if __name__ == '__main__':
	# load synthetic graph
	file_prefix = "data/synthetic/static_SBM/SBM_%d_%d" % (256, 3)
	G, node_community = graph_util.loadSBMGraph(file_prefix)
	node_colors = plot_util.get_node_color(node_community)

	static_embedding = GraphFactorization(2, 1000, 0.01, 1.0)
	static_embedding.learn_embedding(G)

	plot_static_embedding.plot_static_embedding2D(static_embedding.get_embedding(), di_graph=G, node_colors=node_colors)
	plt.show()

