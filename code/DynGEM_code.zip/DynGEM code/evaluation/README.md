# Graph Embedding Evaluation

## Evaluation tasks and metrics
1. Graph Reconstruction:
	* Metrics: precision@k plot, MAP
2. Link Prediction:
	* Metrics: precision@k plot, MAP

When compute the metrics, we can choose to using all pair of vertices or sample certain portion of pairs (0.1%).

## Existing approaches

### Graph Reconstruction:
1. HOPE: precision@k plot
	* Randomly sample 0.1% of all pair of vertex
	* Compute the probability based on embedding
	* Evaluate against the true graph.
2. SDNE: precision@k plot, [MAP](https://www.kaggle.com/wiki/MeanAveragePrecision)


### Link Predicton:
1. HOPE: precision@k
	* Use 80% edges for training and 20% for testing
	* Randomly sample 0.1% of all pair of vertex
	* Evaluate against the test graph.
2. SDNE: precision@k plot, [MAP](https://www.kaggle.com/wiki/MeanAveragePrecision)
3. node2vec: AUC
	* Use 50% edges for training and 50% for testing
	* Use the 50% edges + same number of negative edges to train a binary logistic regression classifier

### Visualization
1. SDNE: use t-SNE to project the dimension into 2d visualization space
2. LINE: use t-SNE to project the dimension into 2d visualization space
3. GraRep: use t-SNE to project the dimension into 2d visualization space
