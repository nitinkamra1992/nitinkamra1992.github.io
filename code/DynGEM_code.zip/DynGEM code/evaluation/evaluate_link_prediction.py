from evaluation import metrics
from utils import evaluation_util
from utils import graph_util 
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from keras.callbacks import EarlyStopping
import numpy as np
import pdb
from dynamic_embedding import sdne_utils
from utils import embed_util

def evaluateStaticLinkPrediction(digraph, graph_embedding, 
                                 train_ratio=0.8,
                                 prev_emb = None,
                                 sample_ratio=None,
                                 is_undirected=True):
    node_num = digraph.number_of_nodes()
    # seperate train and test graph
    train_digraph, test_digraph = evaluation_util.splitDiGraphToTrainTest(digraph,
                                                                          train_ratio=train_ratio,
                                                                          is_undirected=is_undirected)
    # learning graph embedding
    emb = graph_embedding.learn_embedding(train_digraph, prevStepInfo=False)
    if prev_emb is not None:
        emb, _ = embed_util.reorient(prev_emb, emb)
    # evaluation
    if sample_ratio:
        eval_edge_pairs = evaluation_util.getRandomEdgePairs(node_num, sample_ratio, is_undirected)
    else:
        eval_edge_pairs = None
    estimated_adj = graph_embedding.get_reconstructed_adj(emb)
    predicted_edge_list = evaluation_util.getEdgeListFromAdjMtx(estimated_adj, 
        is_undirected=is_undirected, edge_pairs=eval_edge_pairs)

    filtered_edge_list = [e for e in predicted_edge_list if not train_digraph.has_edge(e[0], e[1])]

    MAP = metrics.computeMAP(filtered_edge_list, test_digraph)
    prec_curv, _ = metrics.computePrecisionCurve(filtered_edge_list, test_digraph)
    return (MAP, prec_curv)

def evaluateDynamicLinkPrediction(graph_series, dynamic_embedding, 
                                 train_ratio=0.8,
                                 sample_ratio=None,
                                 file_suffixes=None,
                                 is_undirected=True):
    node_nums = [graph.number_of_nodes() for graph in graph_series]
    MAP_list = [0.0] * len(node_nums)
    prec_curv_list = [None] * len(node_nums)

    for i in range(len(graph_series)):
        train_digraph, test_digraph = evaluation_util.splitDiGraphToTrainTest(graph_series[i],
                                                                            train_ratio=train_ratio,
                                                                            is_undirected=is_undirected)       
        if file_suffixes is None:                                                                   
            temp = graph_series[:i]
            temp.append(train_digraph)
            embeddings = dynamic_embedding.learn_embeddings(temp, prevStepInfo = False)
        else:
            if i == 0:
                embedding = dynamic_embedding.learn_embedding(train_digraph, prevStepInfo=False) 
            else:
                embedding = dynamic_embedding.learn_embedding(train_digraph, prevStepInfo=True, 
                                            loadfilesuffix=file_suffixes[i-1])
        # evaluation
        if sample_ratio:
            eval_edge_pairs = evaluation_util.getRandomEdgePairs(node_nums[i], sample_ratio, is_undirected)
        else:
            eval_edge_pairs = None
        estimated_adj = dynamic_embedding.get_reconstructed_adj()
        predicted_edge_list = evaluation_util.getEdgeListFromAdjMtx(estimated_adj, 
          is_undirected=is_undirected, edge_pairs=eval_edge_pairs)

        filtered_edge_list = [e for e in predicted_edge_list if not train_digraph.has_edge(e[0], e[1])]

        MAP_list[i] = metrics.computeMAP(filtered_edge_list, test_digraph)
        prec_curv_list[i], _ = metrics.computePrecisionCurve(filtered_edge_list, test_digraph)
    return (MAP_list, prec_curv_list)

def evaluateTemporalLinkPredictionDynamic(graph_series, dynamic_embedding, 
                                 sample_ratio=None,
                                 X_dyn=None,
                                 file_suffixes=None,
                                 is_undirected=True):
    node_nums = [graph.number_of_nodes() for graph in graph_series]
    if len(node_nums) == 1:
        raise NameError('Temporal link prediction requires graphs spanning multiple time steps')
    MAP_list = [0.0] * (len(node_nums) - 1)
    prec_curv_list = [None] * (len(node_nums) - 1)

    for i in range(1, len(graph_series)):
        if X_dyn is None:
            if i == 1:
                embeddings = dynamic_embedding.learn_embedding(graph_series[i-1], prevStepInfo = False)
            else:
                embeddings = dynamic_embedding.learn_embedding(graph_series[i-1], prevStepInfo = True)
            estimated_adj = dynamic_embedding.get_reconstructed_adj()
        else:
            estimated_adj = dynamic_embedding.get_reconstructed_adj(X_dyn[i-1], file_suffixes[i-1])
        # evaluation
        if sample_ratio:
            eval_edge_pairs = evaluation_util.getRandomEdgePairs(node_nums[i], sample_ratio, is_undirected)
        else:
            eval_edge_pairs = None
        predicted_edge_list = evaluation_util.getEdgeListFromAdjMtx(estimated_adj, 
          is_undirected=is_undirected, edge_pairs=eval_edge_pairs)


        MAP_list[i-1] = metrics.computeMAP(predicted_edge_list, graph_series[i])
        prec_curv_list[i-1], _ = metrics.computePrecisionCurve(predicted_edge_list, graph_series[i])
    return (MAP_list, prec_curv_list)

def evaluateTemporalLinkPredictionStatic(digraph_curr, digraph_next, graph_embedding, 
                                 X_static=None,
                                 file_suffix=None,
                                 train_ratio=0.8,
                                 sample_ratio=None,
                                 is_undirected=True):
    node_num = digraph_curr.number_of_nodes()  
    if X_static is None:                                                                  
        # learning graph embedding
        graph_embedding.learn_embedding(digraph_curr, prevStepInfo=False)
        estimated_adj = graph_embedding.get_reconstructed_adj()
    else:
        estimated_adj = graph_embedding.get_reconstructed_adj(X_static, file_suffix)
    # evaluation
    if sample_ratio:
        eval_edge_pairs = evaluation_util.getRandomEdgePairs(node_num, sample_ratio, is_undirected)
    else:
        eval_edge_pairs = None
    
    predicted_edge_list = evaluation_util.getEdgeListFromAdjMtx(estimated_adj, 
        is_undirected=is_undirected, edge_pairs=eval_edge_pairs)


    MAP = metrics.computeMAP(predicted_edge_list, digraph_next)
    prec_curv, _ = metrics.computePrecisionCurve(predicted_edge_list, digraph_next)
    return (MAP, prec_curv)

def construct_model(look_back, d):
    model = Sequential()
    model.add(LSTM(500,  input_shape=(look_back, d), return_sequences=True))
    model.add(LSTM(500))
    model.add(Dense(d))
    model.compile(loss='mean_squared_error', optimizer='adam')
    return model

def evaluateTemporalLinkPredictionDynamicWithNodeTracking(graph_series, dynamic_embedding, 
                                 X_dyn=None, file_suffixes=None, sample_ratio=None,
                                 is_undirected=True, look_back=10, train_ratio=0.8):
    node_nums = [graph.number_of_nodes() for graph in graph_series]
    T = len(node_nums)
    if len(node_nums) == 1:
        raise NameError('Temporal link prediction requires graphs spanning multiple time steps')

    embedding = [None] * T
    train_size = int(train_ratio * (T - look_back))
    test_size = T - look_back - train_size
    MAP_list = [0.0] * test_size
    prec_curv_list = [None] * test_size
    nt_p_r = [None] * test_size # Node tracking prediction ratio
    if X_dyn is None:
        for i in range(len(graph_series)):
            if i == 0:
                embedding[i] = dynamic_embedding.learn_embedding(graph_series[i], prevStepInfo = False)
            else:
                embedding[i] = dynamic_embedding.learn_embedding(graph_series[i], prevStepInfo = True)
    else:
        embedding = X_dyn  
    # pdb.set_trace()
    trainX = np.zeros((train_size*embedding[-1].shape[0], look_back, dynamic_embedding._d))
    testX = np.zeros((test_size*embedding[-1].shape[0], look_back, dynamic_embedding._d))
    trainY = np.zeros((train_size*embedding[-1].shape[0], dynamic_embedding._d))
    testY = np.zeros((test_size*embedding[-1].shape[0], dynamic_embedding._d))

    n_samples_train = 0
    n_samples_test = 0
    for t in range(T-look_back):
        n_nodes = embedding[t].shape[0] # Only consider nodes which are present at t = 0 (for each time series)
        if t < train_size:
            trainX[n_samples_train:n_samples_train+n_nodes, 0, :] = embedding[t]
            for tau in range(1, look_back):
                trainX[n_samples_train:n_samples_train+n_nodes, tau, :] = embedding[t+tau][0:n_nodes]
            trainY[n_samples_train:n_samples_train+n_nodes, :] = embedding[t+look_back][0:n_nodes]
            n_samples_train += n_nodes
        else:
            testX[n_samples_test:n_samples_test+n_nodes, 0, :] = embedding[t]
            for tau in range(1, look_back):
                testX[n_samples_test:n_samples_test+n_nodes, tau, :] = embedding[t+tau][0:n_nodes]
            testY[n_samples_test:n_samples_test+n_nodes, :] = embedding[t+look_back][0:n_nodes]
            n_samples_test += n_nodes

    
    '''
    batch_size = 1
    model = Sequential()
    model.add(LSTM(50, batch_input_shape=(batch_size, look_back, dynamic_embedding._d),  stateful=True, return_sequences=True))
    model.add(LSTM(50, batch_input_shape=(batch_size, look_back, dynamic_embedding._d),  stateful=True))
    model.add(Dense(dynamic_embedding._d))
    model.compile(loss='mean_squared_error', optimizer='adam')
    for i in range(10):
        print 'Epoch: %d/10' % i
        model.fit(trainX, trainY, nb_epoch=1, batch_size=batch_size, verbose=2, shuffle=False)
        model.reset_states()
    # Estimate model performance
    trainScore = model.evaluate(trainX, trainY, batch_size=batch_size, verbose=0)
    model.reset_states()
    trainScore = np.sqrt(trainScore)
    # trainScore = scaler.inverse_transform(numpy.array([[trainScore]]))
    print('Train Score: %.2f RMSE' % (trainScore))
    testScore = model.evaluate(testX, testY, batch_size=batch_size, verbose=0)
    model.reset_states()
    testScore = np.sqrt(testScore)
    # testScore = scaler.inverse_transform(numpy.array([[testScore]]))
    print('Test Score: %.2f RMSE' % (testScore))

    predictedEmb = model.predict(testX, batch_size=batch_size, verbose=0)
    model.reset_states()
    '''
    batch_size = 100

    ''' Finding the best number of epochs'''
    model = construct_model(look_back, dynamic_embedding._d)
    early_stop = EarlyStopping(monitor='val_loss', patience=5, verbose=1)
    model.fit(trainX, trainY, nb_epoch=500, batch_size=batch_size, validation_split=0.2, callbacks=[early_stop], verbose=2)
    # pdb.set_trace()

    # model = construct_model(look_back, dynamic_embedding._d)
    # model.fit(trainX, trainY, nb_epoch=early_stop.best_epoch+1, batch_size=batch_size, verbose=2)
    # Estimate model performance
    trainScore = model.evaluate(trainX, trainY, batch_size=batch_size, verbose=0)
    model.reset_states()
    trainScore = np.sqrt(trainScore)
    # trainScore = scaler.inverse_transform(numpy.array([[trainScore]]))
    print('Train Score: %.2f RMSE' % (trainScore))
    testScore = model.evaluate(testX, testY, batch_size=batch_size, verbose=0)
    testScore = np.sqrt(testScore)
    # testScore = scaler.inverse_transform(numpy.array([[testScore]]))
    print('Test Score: %.2f RMSE' % (testScore))

    predictedEmb = model.predict(testX, batch_size=batch_size, verbose=0)
    model.reset_states()
    # pdb.set_trace()
    n_samples_seen = 0 
    for t in range(train_size, T-look_back):
        n_nodes = embedding[t].shape[0]
        X_pred = predictedEmb[n_samples_seen:n_samples_seen+n_nodes, :]
        nt_p_r[t-train_size] = np.linalg.norm(embedding[t+look_back][:n_nodes, :n_nodes] - X_pred)/np.linalg.norm(embedding[t+look_back][:n_nodes, :n_nodes] - embedding[t+look_back-1][:n_nodes, :n_nodes]) # Node tracking prediction ratio
        estimated_adj = dynamic_embedding.get_reconstructed_adj(X_pred, file_suffixes[t+look_back-1])
        estimated_adj = sdne_utils.graphify(estimated_adj)
        # evaluation
        if sample_ratio:
            eval_edge_pairs = evaluation_util.getRandomEdgePairs(n_nodes, sample_ratio, is_undirected)
        else:
            eval_edge_pairs = None
        predicted_edge_list = evaluation_util.getEdgeListFromAdjMtx(estimated_adj, 
          is_undirected=is_undirected, edge_pairs=eval_edge_pairs)
        MAP_list[t-train_size] = metrics.computeMAP(predicted_edge_list, graph_series[t+look_back])
        prec_curv_list[t-train_size], _ = metrics.computePrecisionCurve(predicted_edge_list, graph_series[t+look_back])
        n_samples_seen += n_nodes
    # for i in range(1, len(graph_series)):
    #     if i == 1:
    #         embedding[i] = dynamic_embedding.learn_embedding(graph_series[i-1], prevStepInfo = False)
    #     else:
    #         embedding[i] = dynamic_embedding.learn_embedding(graph_series[i-1], prevStepInfo = True)
    #     # evaluation
    #     if sample_ratio:
    #         eval_edge_pairs = evaluation_util.getRandomEdgePairs(node_nums[i], sample_ratio, is_undirected)
    #     else:
    #         eval_edge_pairs = None
    #     estimated_adj = dynamic_embedding.get_reconstructed_adj()
    #     predicted_edge_list = evaluation_util.getEdgeListFromAdjMtx(estimated_adj, 
    #       is_undirected=is_undirected, edge_pairs=eval_edge_pairs)


    #     MAP_list[i-1] = metrics.computeMAP(predicted_edge_list, graph_series[i])
    #     prec_curv_list[i-1], _ = metrics.computePrecisionCurve(predicted_edge_list, graph_series[i])
    return (MAP_list, prec_curv_list, nt_p_r)