from evaluation import metrics
from utils import embed_util, graph_util

def evaluateDynamicEmbeddingStability(graph_series, dynamic_embedding, 
                            X_dyn=None, is_undirected=True):
    if X_dyn is None:
        embeds = dynamic_embedding.learn_embeddings(graph_series, False)
    else:
        embeds = X_dyn
    devs = [0.0] * (len(embeds)-1)
    absAnomaly = [0.0] * (len(embeds)-1)
    relAnomaly = [0.0] * (len(embeds)-1)
    for i in range(len(embeds)-1):
        adj = graph_util.transform_DiGraph_to_adj(graph_series[i])
        adj_next = graph_util.transform_DiGraph_to_adj(graph_series[i+1])
        devs[i] = metrics.getStabilityDev(embeds[i], embeds[i+1], adj, adj_next)
        absAnomaly[i], cn = metrics.getAbsoluteEmbeddingShift(embeds[i], embeds[i+1], graph_series[i], graph_series[i+1])
        relAnomaly[i] = absAnomaly[i]/(len(cn)*embeds[i].shape[1])
    # return float(sum(devs)/len(devs))
    return devs, absAnomaly, relAnomaly

def evaluateStaticEmbeddingStability(graph_series, static_embedding, 
                            X_stat=None, X_stat_align=None, is_undirected=True):
    if X_stat is None:
        embeds = [static_embedding.learn_embedding(g, False) for g in graph_series]
    elif X_stat_align is None:
        raise 'X_stat specified but not X_stat_align'
    else:
        embeds = X_stat
    devs = [0.0] * (len(embeds)-1)
    anomaly = [0.0] * (len(embeds)-1)
    for i in range(len(embeds)-1):
        adj = graph_util.transform_DiGraph_to_adj(graph_series[i])
        adj_next = graph_util.transform_DiGraph_to_adj(graph_series[i+1])
        devs[i] = metrics.getStabilityDev(embeds[i], embeds[i+1], adj, adj_next)
    # return float(sum(devs)/len(devs))
    devs_reorient = [0.0] * (len(embeds)-1)
    for i in range(len(embeds)-1):
        adj = graph_util.transform_DiGraph_to_adj(graph_series[i])
        adj_next = graph_util.transform_DiGraph_to_adj(graph_series[i+1])
        if X_stat is None:                       
            embeds[i+1], _ = embed_util.reorient(embeds[i], embeds[i+1])
            devs_reorient[i] = metrics.getStabilityDev(embeds[i], embeds[i+1], adj, adj_next)
            anomaly[i] = metrics.getEmbeddingShift(embeds[i], embeds[i+1], adj, adj_next)
        else:
            anomaly[i] = metrics.getEmbeddingShift(X_stat_align[i], X_stat_align[i+1], adj, adj_next)
            devs_reorient[i] = metrics.getStabilityDev(X_stat_align[i], X_stat_align[i+1], adj, adj_next)
    return devs, devs_reorient, anomaly