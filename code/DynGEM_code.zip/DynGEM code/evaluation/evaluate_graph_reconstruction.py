from evaluation import metrics
from utils import evaluation_util
from utils import graph_util

def evaluateStaticGraphReconstruction(digraph, graph_embedding,
                                      X_stat=None, file_suffix=None,
                                      sample_ratio=None, is_undirected=True):
    node_num = digraph.number_of_nodes()
    if X_stat is None:
        # learning graph embedding
        graph_embedding.learn_embedding(digraph, prevStepInfo = False)
    # evaluation
    if sample_ratio:
        eval_edge_pairs = evaluation_util.getRandomEdgePairs(node_num, sample_ratio, is_undirected)
    else:
        eval_edge_pairs = None
    if X_stat is None:
        estimated_adj = graph_embedding.get_reconstructed_adj()
    elif file_suffix is None:
        estimated_adj = graph_embedding.get_reconstructed_adj(X_stat)
    else:
        estimated_adj = graph_embedding.get_reconstructed_adj(X_stat, file_suffix)

    predicted_edge_list = evaluation_util.getEdgeListFromAdjMtx(estimated_adj, 
        is_undirected=is_undirected, edge_pairs=eval_edge_pairs)

    MAP = metrics.computeMAP(predicted_edge_list, digraph)
    prec_curv, _ = metrics.computePrecisionCurve(predicted_edge_list, digraph)

    return (MAP, prec_curv)

def evaluateDynamicGraphReconstruction(graph_series, dynamic_embedding,  
                                      X_dyn = None, sample_ratio=None,
                                      file_suffixes = None, is_undirected=True):
    node_nums = [graph.number_of_nodes() for graph in graph_series]
    MAP_list = [0.0] * len(node_nums)
    prec_curv_list = [None] * len(node_nums)

    # evaluation
    for i in range(len(graph_series)):
        if X_dyn is None:
            if i == 0:
                embedding = dynamic_embedding.learn_embedding(graph_series[i], prevStepInfo = False)
            else:
                embedding = dynamic_embedding.learn_embedding(graph_series[i], prevStepInfo = True)
            estimated_adj = dynamic_embedding.get_reconstructed_adj()
        else:
            estimated_adj = dynamic_embedding.get_reconstructed_adj(X_dyn[i], file_suffixes[i])
        if sample_ratio:
            eval_edge_pairs = evaluation_util.getRandomEdgePairs(node_nums[i], sample_ratio, is_undirected)
        else:
            eval_edge_pairs = None        
        
        predicted_edge_list = evaluation_util.getEdgeListFromAdjMtx(estimated_adj, 
            is_undirected=is_undirected, edge_pairs=eval_edge_pairs)

        MAP_list[i] = metrics.computeMAP(predicted_edge_list, graph_series[i])
        prec_curv_list[i], _ = metrics.computePrecisionCurve(predicted_edge_list, graph_series[i])

    return (MAP_list, prec_curv_list)

def evaluateStaticGraphReconstructionGraphFac(digraph, graph_embedding,
                                      X_stat=None,
                                      sample_ratio=None, is_undirected=True):
    node_num = digraph.number_of_nodes()
    if X_stat is None:
        # learning graph embedding
        graph_embedding.learn_embedding(digraph, prevEmbed = None)
    # evaluation
    if sample_ratio:
        eval_edge_pairs = evaluation_util.getRandomEdgePairs(node_num, sample_ratio, is_undirected)
    else:
        eval_edge_pairs = None
    if X_stat is None:
        estimated_adj = graph_embedding.get_reconstructed_adj()
    else:
        estimated_adj = graph_embedding.get_reconstructed_adj(X_stat)
    predicted_edge_list = evaluation_util.getEdgeListFromAdjMtx(estimated_adj, 
        is_undirected=is_undirected, edge_pairs=eval_edge_pairs)

    MAP = metrics.computeMAP(predicted_edge_list, digraph)
    prec_curv, _ = metrics.computePrecisionCurve(predicted_edge_list, digraph)

    return (MAP, prec_curv)

def evaluateDynamicGraphReconstructionGraphFac(graph_series, dynamic_embedding,  
                                      X_dyn = None, sample_ratio=None,
                                      is_undirected=True):
    node_nums = [graph.number_of_nodes() for graph in graph_series]
    MAP_list = [0.0] * len(node_nums)
    prec_curv_list = [None] * len(node_nums)

    # evaluation
    for i in range(len(graph_series)):
        if X_dyn is None:
            if i == 0:
                embedding = dynamic_embedding.learn_embedding(graph_series[i], prevEmbed = None)
            else:
                embedding = dynamic_embedding.learn_embedding(graph_series[i], prevEmbed = X_dyn[i-1])
            estimated_adj = dynamic_embedding.get_reconstructed_adj()
        else:
            estimated_adj = dynamic_embedding.get_reconstructed_adj(X_dyn[i])
        if sample_ratio:
            eval_edge_pairs = evaluation_util.getRandomEdgePairs(node_nums[i], sample_ratio, is_undirected)
        else:
            eval_edge_pairs = None        
        
        predicted_edge_list = evaluation_util.getEdgeListFromAdjMtx(estimated_adj, 
            is_undirected=is_undirected, edge_pairs=eval_edge_pairs)

        MAP_list[i] = metrics.computeMAP(predicted_edge_list, graph_series[i])
        prec_curv_list[i], _ = metrics.computePrecisionCurve(predicted_edge_list, graph_series[i])

    return (MAP_list, prec_curv_list)