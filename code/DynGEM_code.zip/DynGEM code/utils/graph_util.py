import cPickle as pickle
import numpy as np
import networkx as nx
import random
import itertools
import time
import pdb

def transform_DiGraph_to_adj(di_graph):
    n = di_graph.number_of_nodes()
    adj = np.zeros((n ,n))
    for st, ed, w in di_graph.edges_iter(data='weight', default=1):
        adj[st, ed] = w
    return adj

def transform_adj_to_DiGraph(adj):
    n = adj.shape[0]
    di_graph = nx.DiGraph()
    di_graph.add_nodes_from(range(n))
    for i in xrange(n):
        for j in xrange(n):
            if(i != j):
                if(adj[i, j] > 0):
                    di_graph.add_edge(i, j, weight=adj[i, j])
    return di_graph

def sampleEdgesRandomlyUndirected(Gs, sample_ratio=0.9):
    sampledGs = []
    for G in Gs:
        G_temp = G.to_undirected()
        tobeRemovedEdges = random.sample(G_temp.edges(), int((1-sample_ratio)*G_temp.number_of_edges()))
        G_temp.remove_edges_from(tobeRemovedEdges)
        sampledGs.append(G_temp.to_directed())
    return sampledGs

def addBackroundNodes(Gs, fraction_nodes_added):
    newGs = []
    n = Gs[0].number_of_nodes()
    k = int(fraction_nodes_added*n)
    avg_deg = Gs[0].number_of_edges()/float(n)
    newEdgeMat = np.random.choice(2, [k,n], p=[1-avg_deg/float(n), avg_deg/float(n)])
    newEdgeListPair = np.where(newEdgeMat>0)
    newEdgeList = zip(newEdgeListPair[0]+n, newEdgeListPair[1])
    for G in Gs:
        G_temp = G.to_undirected()
        G_temp.add_nodes_from(range(n, n+k))
        G_temp.add_edges_from(newEdgeList)
        newGs.append(G_temp.to_directed())
    return newGs

def truncateTemporalGraphSeries(Gs, minDegree = 1, verbose=True):
    to_remove = []
    for G in Gs:
        outdegrees = G.out_degree()
        to_remove += [idx for idx in outdegrees if outdegrees[idx] < minDegree]
        to_remove = list(set(to_remove))
    to_keep = list(set(Gs[0].nodes()) - set(to_remove))
    nodeMapping = dict(zip(to_keep, range(len(to_keep))))
    truncatedGs = []
    for G in Gs:
        truncatedGs.append(nx.relabel_nodes(G.subgraph(to_keep), nodeMapping))
    if verbose:
        for idx, digraph in enumerate(truncatedGs):
            print 't: %d, |V|: %d, |E|: %d, |E|/|V|: %f' % (idx, digraph.number_of_nodes(), digraph.number_of_edges(), digraph.number_of_edges()/float(digraph.number_of_nodes()))
    return truncatedGs, nodeMapping

def randwalk_DiGraph_to_adj(di_graph, node_frac=0.1, n_walks_per_node=5, len_rw=2):
    t0 = time.time()
    n = di_graph.number_of_nodes()
    adj = np.zeros((n ,n))
    rw_node_num = int(node_frac * n)
    rw_node_list = np.random.choice(n, size=[rw_node_num], replace=False, p=None)
    for node in rw_node_list:
        for walk in range(n_walks_per_node):
            cur_node = node
            for step in range(len_rw):
                cur_neighbors = di_graph.neighbors(cur_node)
                try:
                    neighbor_node = np.random.choice(cur_neighbors)
                except:
                    continue
                try:
                    adj[cur_node, neighbor_node] = di_graph.get_edge_data(cur_node, neighbor_node)['weight']
                    adj[neighbor_node, cur_node] = di_graph.get_edge_data(cur_node, neighbor_node)['weight']
                except KeyError:
                    adj[cur_node, neighbor_node] = 1
                    adj[neighbor_node, cur_node] = 1
                cur_node = neighbor_node
    print('Time taken for random walk on graph with {0} nodes = {1}'.format(n, time.time() - t0))
    return adj

def addChaos(di_graphs, k):
    anomaly_time_steps = sorted(random.sample(range(len(di_graphs)), k))
    for t in anomaly_time_steps:
        n = di_graphs[t].number_of_nodes()
        e = di_graphs[t].number_of_edges()
        di_graphs[t] = nx.fast_gnp_random_graph(n, e/float(n*(n-1)), seed=None, directed=False)
        di_graphs[t] = di_graphs[t].to_directed()
    return di_graphs, anomaly_time_steps

def addNodeAnomalies(di_graphs, p, k):
    anomaly_time_steps = sorted(random.sample(range(len(di_graphs)), k))
    for t in anomaly_time_steps:
        n_nodes= di_graphs[t].number_of_nodes()
        anomalous_nodes_idx = np.random.choice([0,1], size=(n_nodes, 1), p=(1-p, p))
        node_list = np.array(di_graphs[t].nodes())
        node_list = node_list.reshape((n_nodes, 1))
        anomalous_nodes = np.multiply(anomalous_nodes_idx, node_list)
        anomalous_nodes = anomalous_nodes[anomalous_nodes > 0]
        # pdb.set_trace()
        di_graphs[t].add_edges_from(itertools.product(list(anomalous_nodes), range(n_nodes)))
        di_graphs[t].add_edges_from(itertools.product(range(n_nodes), list(anomalous_nodes)))
        print 'Nodes: %d, Edges: %d' % (di_graphs[t].number_of_nodes(), di_graphs[t].number_of_edges())
    return anomaly_time_steps


def loadSBMGraph(file_prefix):
    graph_file = file_prefix + '_graph.gpickle'
    G = nx.read_gpickle(graph_file)
    node_file = file_prefix + '_node.pkl'
    with open(node_file, 'rb') as fp:
        node_community = pickle.load(fp)
    return (G, node_community)

def loadRealGraphSeries(file_prefix, startId, endId):
    graphs = []
    for file_id in range(startId, endId + 1):
        graph_file = file_prefix + str(file_id) + '_graph.gpickle'
        graphs.append(nx.read_gpickle(graph_file))
    return graphs

def loadDynamicSBmGraph(file_perfix, length):
    graph_files = ['%s_%d_graph.gpickle' % (file_perfix, i) for i in xrange(length)]
    info_files = ['%s_%d_node.pkl' % (file_perfix, i) for i in xrange(length)]

    graphs = [nx.read_gpickle(graph_file) for graph_file in graph_files]
    
    nodes_comunities = []
    perturbations = []
    for info_file in info_files:
        with open(info_file, 'rb') as fp:
            node_infos = pickle.load(fp)
            nodes_comunities.append(node_infos['community'])
            perturbations.append(node_infos['perturbation'])

    return zip(graphs, nodes_comunities, perturbations)


def saveDynamicSBmGraph(file_perfix, dynamic_graphs):
    length = len(dynamic_graphs)
    graph_files = ['%s_%d_graph.gpickle' % (file_perfix, i) for i in xrange(length)]
    info_files = ['%s_%d_node.pkl' % (file_perfix, i) for i in xrange(length)]

    for i in xrange(length):
        # save graph
        nx.write_gpickle(dynamic_graphs[i][0], graph_files[i])
        # save additional node info
        with open(info_files[i], 'wb') as fp:
            node_infos = {}
            node_infos['community'] = dynamic_graphs[i][1]
            node_infos['perturbation'] = dynamic_graphs[i][2]
            pickle.dump(node_infos, fp)