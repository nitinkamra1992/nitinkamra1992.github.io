import scholarly
import numpy as np

def getAuthorsCitationCount(author_names, save_file = None):
	authorCitations = np.zeros(len(author_names))

	for idx, author in enumerate(author_names):
		print "Getting authors' citations: %d/%d" % (idx, len(author_names))
		search_query = scholarly.search_author(author)
		try:
			author_info = next(search_query)
			authorCitations[idx] = author_info.citedby
		except:
			# The author wasn't in Google Scholar database
			pass
	if save_file is not None:
		np.savetxt(save_file, (author_names, authorCitations), fmt='%s')
	return authorCitations

if __name__ == "__main__":
	authors = ['Viktor K. Prasanna', 'Albert Einstein', 'E. Elizalde', 'Kabutar']
	authorCitations = getAuthorsCitationCount(authors)
	for idx, cit in enumerate(authorCitations):
		print '%s: %d' % (authors[idx], cit)