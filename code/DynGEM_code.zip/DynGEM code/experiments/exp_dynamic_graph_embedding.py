disp_avlbl = True
from os import environ
if 'DISPLAY' not in environ:
    disp_avlbl = False
    import matplotlib
    matplotlib.use('Agg')
import matplotlib.pyplot as plt

import pdb
import time
import cPickle
import scipy.stats
import sys
import numpy as np
import networkx as nx
import pandas as pd
sys.path.append('./')

from evaluation import metrics
from evaluation.evaluate_graph_reconstruction import *
from evaluation.evaluate_link_prediction import *
from evaluation.evaluate_embedding_stability import *
from dynamic_embedding.sdne_dynamic import SDNE
from dynamic_embedding.graphFac_dynamic import GraphFactorization
from graph_generation import dynamic_SBM_graph, dynamic_military_call_graph

from utils import graph_util, embed_util, plot_util, evaluation_util
from utils.plot_util import plot

def experimentDynamicGraphEmbedding(true_digraphs, graph_embedding_list, result_path_prefix,
    link_prediction_splits, link_prediction_rounds, time_step_eval = 2,
    load_emb_file=False, is_undirected=True, sample_ratio=None, train_ratio = 0.8, dataName = 'Lebanon', exp=[False, False], subsample=False, nodeNames=None, anomaly_time_steps=[]):
    # generate result file
    f = open('%s_summary.txt' % result_path_prefix, 'w')  
    fig_n = 1
    T = len(true_digraphs)
    X_stat = [None]*T
    X_dyn = [None]*T
    X_stat_align = [None]*T
    prec_curves = [[]]*T
    prec_curv_t = []
    anomaly = []
    anomaly_reorient = []
    
    for graph_embdding in graph_embedding_list:
        meth_summary = graph_embdding.get_method_summary()
        file_suffixes_static = ['%s_static_%d' % (meth_summary, t) for t in range(T)]
        file_suffixes_dynamic = ['%s_dynamic_%d' % (meth_summary, t) for t in range(T)]

        t1 = time.time()
        # Compute static, aligned static and dynamic embeddings from the graph series
        for t in range(T):
            print 'LEARNING DYNAMIC EMBEDDINGS: GRAPH %d' % t
            if not load_emb_file:
                if t == 0:
                    X_dyn[t] = graph_embdding.learn_embedding(true_digraphs[t], prevStepInfo = False, savefilesuffix=file_suffixes_dynamic[t], subsample=subsample)
                else:
                    X_dyn[t] = graph_embdding.learn_embedding(true_digraphs[t], prevStepInfo = True, savefilesuffix=file_suffixes_dynamic[t], subsample=subsample)
            else:
                X_dyn[t] = graph_embdding.get_embedding(file_suffixes_dynamic[t])
        t2 = time.time()
        print 'Time taken (dynamic): %f' % (t2 - t1)
        
        # Use the embeddings obtained for all the experiments
        if exp[0]:
            # TASK 1: GRAPH RECONSTRUCTION
            print '---------------------TESTING GRAPH RECONSTRUCTION---------------------'
            f.write('Graph Reconstruction\n')
            f.write('Method\t%s\n' % metrics.getMetricsHeader())
            r_s = [] # r_s is the reconstruction precision curve for static emb
            r_d = []
            for t in range(T):
                r_s.append([])
                r_d.append([])
            MAPs, prec_curves = evaluateDynamicGraphReconstruction(true_digraphs, graph_embdding,
             X_dyn=X_dyn, file_suffixes = file_suffixes_dynamic, is_undirected=is_undirected, sample_ratio=sample_ratio)
            f.write('%s\n' % graph_embdding.get_method_summary())
            for t in range(T):
                f.write('\tT = %d' % (t))
                cPickle.dump(prec_curves[t], open('%s_prec_curves_recon_%s_%d.pickle' % (result_path_prefix, graph_embdding.get_method_summary(), t), 'wb'))
                f.write('\n\t\tDynamic: %f\t%s\n' % (MAPs[t], 
                                                metrics.getPrecisionReport(prec_curves[t], true_digraphs[t].number_of_edges())))
                r_d[t].append(prec_curves[t])
        # Use the embeddings obtained for all the experiments
        if exp[1]:
            # TASK 2: ANOMALY
            print '---------------------Anomaly---------------------'
            f.write('Anomaly\n')
            f.write('Method\t%s\n' % metrics.getMetricsHeader())
            r_s = [] # r_s is the reconstruction precision curve for static emb
            r_d = []
            for t in range(T):
                r_s.append([])
                r_d.append([])
            devs_dynamic, absAnomaly, relAnomaly = evaluateDynamicEmbeddingStability(true_digraphs, graph_embdding, X_dyn=X_dyn, is_undirected=True)

            f.write('%s\n' % graph_embdding.get_method_summary())
            if T > 1:
                f.write('\t\tDynamic stability: %s\n' % '\t'.join(map(str, devs_dynamic)))
                f.write('\t\tDynamic absolute anomaly: %s\n' % '\t'.join(map(str, absAnomaly)))
                f.write('\t\tDynamic relative anomaly: %s\n' % '\t'.join(map(str, relAnomaly)))
                node_anomaly = metrics.getNodeAnomaly(X_dyn, true_digraphs)
                top_anom_nodes = node_anomaly.argsort(axis=0)[-10:,:][::-1, :]
                top_anom = np.sort(node_anomaly, axis=0)[-10:,:][::-1, :]
                top_anom_cum = top_anom.sum(axis=0)
                cPickle.dump(absAnomaly, open('%s_abs_anomaly_%s.pickle' % (result_path_prefix, graph_embdding.get_method_summary()), 'wb'))
                cPickle.dump(relAnomaly, open('%s_rel_anomaly_%s.pickle' % (result_path_prefix, graph_embdding.get_method_summary()), 'wb'))
                cPickle.dump(top_anom_cum, open('%s_top_anomaly_cum_%s.pickle' % (result_path_prefix, graph_embdding.get_method_summary()), 'wb'))
                cPickle.dump(node_anomaly, open('%s_node_anomaly_%s.pickle' % (result_path_prefix, graph_embdding.get_method_summary()), 'wb'))
                for t in range(T):
                    f.write('\tT = %d' % (t))
                    if t < T-1:
                        f.write('\t\tTop anomalous nodes: %s\n' % ', '.join(map(str, top_anom_nodes[:, t])))
                        if nodeNames:
                            for node in top_anom_nodes[:, t]:
                                f.write('\t\tClasses of top anomalous nodes: %s, ' % nodeNames[node])
                            f.write('\n')
                ts_df_abs = pd.DataFrame(absAnomaly, columns=['Absolute Anomaly Scores'])
                ts_df_rel = pd.DataFrame(relAnomaly, columns=['Relative Anomaly Scores'])
                ts_df_top_cum = pd.DataFrame(top_anom_cum, columns=['Top Cumulative Anomaly Scores'])
                try:            
                    plot_util.plot_ts(ts_df_abs, '%s' % dataName, anomaly_time_steps, 
                            save_file_name='%s_absAnomalyPlot.png' % result_path_prefix, 
                            xLabel='Time', yLabel='Absolute Anomaly')
                    plot_util.plot_ts(ts_df_rel, '%s' % dataName, anomaly_time_steps, 
                            save_file_name='%s_relAnomalyPlot.png' % result_path_prefix, 
                            xLabel='Time', yLabel='Relative Anomaly')
                    plot_util.plot_ts(ts_df_top_cum, '%s' % dataName, anomaly_time_steps, 
                            save_file_name='%s_topCumAnomalyPlot.png' % result_path_prefix, 
                            xLabel='Time', yLabel='Top Cumulative Anomaly')
                except:
                    print 'Cannot plot. Please run outside of screen to make the plots. Alternatively plt from %s_anomaly_%s.pickle' % (result_path_prefix, graph_embdding.get_method_summary())

        if exp[2]:
            # TASK 3: LINK PREDICTION
            print('---------------------TESTING LINK PREDICTION---------------------')
            f.write('Link Prediction\n')
            f.write('Method\tSplitRatio\tRound\t%s\n' % metrics.getMetricsHeader())
            lp_s = [] # lp_s is the link prediction precision curve for static emb
            lp_d = []
            for t in range(T):
                lp_s.append([])
                lp_d.append([])
            for round_id in xrange(link_prediction_rounds):
                for split_ratio in link_prediction_splits:
                    MAPs, prec_curves = evaluateDynamicLinkPrediction(true_digraphs, graph_embdding, 
                        split_ratio, file_suffixes=file_suffixes_dynamic, is_undirected=is_undirected, sample_ratio=sample_ratio)
                    f.write('%s\n' % graph_embdding.get_method_summary())
                    for t in range(T):
                        f.write('\tT = %d' % (t))
                        cPickle.dump(prec_curves[t], open('%s_prec_curves_lp_%s_%d.pickle' % (result_path_prefix, graph_embdding.get_method_summary(), t), 'wb'))
                        f.write('\n\t\tDynamic: %f\t%s\n' % (MAPs[t], 
                                                        metrics.getPrecisionReport(prec_curves[t], true_digraphs[t].number_of_edges())))
                        lp_d[t].append(prec_curves[t])
        f.close()
        return prec_curves[t], prec_curv_t, t2-t1, anomaly


def expLebanonSampled():
    t1 = time.time()
    for ev_id in range(0, 1):
        for sample_ratio in np.arange(0.9, 0, -0.1):
            digraphs_leb2 = graph_util.loadRealGraphSeries('data/real/lebanon_v2/Lebanon_v2_ev%d/day_' % ev_id, 0, 5)
            for idx, digraph in enumerate(digraphs_leb2):
                print 'Before sampling, N: %d, E: %d, |E|/|V|: %f' % (digraph.number_of_nodes(), digraph.number_of_edges(), digraph.number_of_edges()/float(digraph.number_of_nodes()))
            digraphs_leb2 = graph_util.sampleEdgesRandomlyUndirected(digraphs_leb2, sample_ratio=sample_ratio)
            for idx, digraph in enumerate(digraphs_leb2):
                print 'After sampling, N: %d, E: %d, |E|/|V|: %f' % (digraph.number_of_nodes(), digraph.number_of_edges(), digraph.number_of_edges()/float(digraph.number_of_nodes()))
            sdne_embeddings_leb2 = [SDNE(d=100, beta=5, alpha=1e-6, nu1=1e-6, nu2=1e-6, K=3, n_units=[500, 300,], rho=0.3, n_iter=50, n_iter_subs=50, xeta=1e-4, n_batch=500, modelfile=['./intermediate/enc_model.json', './intermediate/dec_model.json'], weightfile=['./intermediate/enc_weights.hdf5', './intermediate/dec_weights.hdf5'], node_frac=1, n_walks_per_node=1, len_rw=1)]
            result_prefix = 'result/test_sdne_leb%d_sample_ratio_%f' % (ev_id, sample_ratio)
            exp = [True, True, False]
            pc_sdne_dyn,  pc_sdne_stat, t_dyn_leb2, anomaly_sdne = experimentDynamicGraphEmbedding(digraphs_leb2, sdne_embeddings_leb2, result_prefix, [0.8], 1, is_undirected=True, exp=exp, load_emb_file = False, subsample=False)   
    t2 = time.time()
    print 'Total time taken: %f' % (t2-t1)

def expLebanon(background=False):
    t1 = time.time()
    for ev_id in range(0, 1):
        for fraction_nodes_added in np.arange(0.1, 1, 0.1):
            digraphs_leb2 = graph_util.loadRealGraphSeries('data/real/lebanon_v2/Lebanon_v2_ev%d/day_' % ev_id, 0, 5)
            for idx, digraph in enumerate(digraphs_leb2):
                print 'Before background addition, N: %d, E: %d, |E|/|V|: %f' % (digraph.number_of_nodes(), digraph.number_of_edges(), digraph.number_of_edges()/float(digraph.number_of_nodes()))
            digraphs_leb2 = graph_util.addBackroundNodes(digraphs_leb2, fraction_nodes_added)
            for idx, digraph in enumerate(digraphs_leb2):
                print 'After background addition, N: %d, E: %d, |E|/|V|: %f' % (digraph.number_of_nodes(), digraph.number_of_edges(), digraph.number_of_edges()/float(digraph.number_of_nodes()))
            sdne_embeddings_leb2 = [SDNE(d=100, beta=5, alpha=1e-6, nu1=1e-6, nu2=1e-6, K=3, n_units=[500, 300,], rho=0.3, n_iter=50, n_iter_subs=50, xeta=1e-4, n_batch=500, modelfile=['./intermediate/enc_model.json', './intermediate/dec_model.json'], weightfile=['./intermediate/enc_weights.hdf5', './intermediate/dec_weights.hdf5'], node_frac=1, n_walks_per_node=1, len_rw=1)]
            result_prefix = 'result/test_sdne_leb%d_background_ratio_%f' % (ev_id, fraction_nodes_added)
            exp = [True, True, False]
            pc_sdne_dyn,  pc_sdne_stat, t_dyn_leb2, anomaly_sdne = experimentDynamicGraphEmbedding(digraphs_leb2, sdne_embeddings_leb2, result_prefix, [0.8], 1, is_undirected=True, exp=exp, load_emb_file = False, subsample=False)   
    t2 = time.time()
    print 'Total time taken: %f' % (t2-t1)

def expLebanonNaquora():
    t1 = time.time()
    digraphs_leb2 = graph_util.loadRealGraphSeries('data/real/lebanon_naquora/ev20/day_', 0, 5)   
    for idx, digraph in enumerate(digraphs_leb2):
        print 'N: %d, E: %d' % (digraph.number_of_nodes(), digraph.number_of_edges())
    sdne_embeddings_leb2 = [SDNE(d=200, beta=5, alpha=1e-6, nu1=1e-6, nu2=1e-6, K=3, n_units=[1000, 500], rho=0.3, n_iter=25, n_iter_subs=25, xeta=5e-4, n_batch=500, modelfile=['./intermediate/enc_model.json', './intermediate/dec_model.json'], weightfile=['./intermediate/enc_weights.hdf5', './intermediate/dec_weights.hdf5'], node_frac=1, n_walks_per_node=1, len_rw=1)]
    result_prefix = 'result/test_sdne_leb_naquoraev20'
    exp = [False, True, False]
    pc_sdne_dyn,  pc_sdne_stat, t_dyn_leb2, anomaly_sdne = experimentDynamicGraphEmbedding(digraphs_leb2, sdne_embeddings_leb2, result_prefix, [0.8], 1, is_undirected=True, exp=exp, load_emb_file = False, subsample=False)   
    t2 = time.time()
    print 'Total time taken: %f' % (t2-t1)

def expLebanonNaquoraText():
    t1 = time.time()
    digraphs_leb2 = graph_util.loadRealGraphSeries('data/real/lebanon_naquora_text/ev6/day_', 0, 80)   
    for idx, digraph in enumerate(digraphs_leb2):
        print 'N: %d, E: %d' % (digraph.number_of_nodes(), digraph.number_of_edges())
    sdne_embeddings_leb2 = [SDNE(d=200, beta=10, alpha=1e-6, nu1=1e-6, nu2=1e-6, K=3, n_units=[1000, 500], rho=0.3, n_iter=25, n_iter_subs=25, xeta=5e-4, n_batch=500, modelfile=['./intermediate/enc_model.json', './intermediate/dec_model.json'], weightfile=['./intermediate/enc_weights.hdf5', './intermediate/dec_weights.hdf5'], node_frac=1, n_walks_per_node=1, len_rw=1)]
    result_prefix = 'result/test_sdne_leb_naquoraText_ev6'
    exp = [False, True, False]
    pc_sdne_dyn,  pc_sdne_stat, t_dyn_leb2, anomaly_sdne = experimentDynamicGraphEmbedding(digraphs_leb2, sdne_embeddings_leb2, result_prefix, [0.8], 1, is_undirected=True, exp=exp, load_emb_file = False, subsample=False)   
    t2 = time.time()
    print 'Total time taken: %f' % (t2-t1)

def expTwitterFullMention():
    t1 = time.time()
    digraphs = graph_util.loadRealGraphSeries('data/real/Twitter_full_mention/year_', 0, 5)
    digraphs, _ = graph_util.truncateTemporalGraphSeries(digraphs, minDegree = 1)
    for idx, digraph in enumerate(digraphs):
        print 'N: %d, E: %d' % (digraph.number_of_nodes(), digraph.number_of_edges())
    sdne_embeddings_leb2 = [SDNE(d=200, beta=5, alpha=1e-6, nu1=1e-6, nu2=1e-6, K=3, n_units=[1000, 500], rho=0.3, n_iter=25, n_iter_subs=25, xeta=5e-4, n_batch=500, modelfile=['./intermediate/enc_model.json', './intermediate/dec_model.json'], weightfile=['./intermediate/enc_weights.hdf5', './intermediate/dec_weights.hdf5'], node_frac=1, n_walks_per_node=1, len_rw=1)]
    result_prefix = 'result/test_sdne_twitter_full_mention'
    exp = [True, True, False]
    pc_sdne_dyn,  pc_sdne_stat, t_dyn_leb2, anomaly_sdne = experimentDynamicGraphEmbedding(digraphs, sdne_embeddings_leb2, result_prefix, [0.8], 1, is_undirected=True, exp=exp, load_emb_file = False, subsample=False)   
    t2 = time.time()
    print 'Total time taken: %f' % (t2-t1)

def expSBM():
    t1 = time.time()
    node_num = 1000
    community_num = 3
    node_change_num = 10
    length = 1
    digraph_series = dynamic_SBM_graph.get_random_perturbation_series(node_num, community_num, length, node_change_num)
    digraphs_syn = [g[0] for g in digraph_series]
    sdne_embeddings_syn = [SDNE(d=100, beta=5, alpha=1e-5, nu1=1e-6, nu2=1e-6, K=3, n_units=[500, 300,], rho=0.3, n_iter=30, n_iter_subs=10, xeta=0.01, n_batch=500, modelfile=['./intermediate/enc_model.json', './intermediate/dec_model.json'], weightfile=['./intermediate/enc_weights.hdf5', './intermediate/dec_weights.hdf5'], node_frac=1, n_walks_per_node=5, len_rw=2)]
    result_prefix = 'result/test_sdne_sbm'
    exp = [True, False]
    pc_sdne_dyn,  pc_sdne_stat, t_dyn_leb2, anomaly_sdne = experimentDynamicGraphEmbedding(digraphs_syn, sdne_embeddings_syn, result_prefix, [0.8], 1, is_undirected=True, exp=exp, load_emb_file = False, subsample=False)   
    t2 = time.time()


if __name__ == '__main__':
    t1 = time.time()
    expLebanonNaquoraText()
    # expLebanon()
    # expLebanonNaquora()
    # expTwitterFullMention()
    # expSBM()
    t2 = time.time()
    print 'Total time taken: %f' % (t2-t1)
