import plot_util
import pandas as pd
import cPickle

anomaly_time_steps = ['11', '16']
num_edges = cPickle.load(open('result/num_edges_syn_chaos.pickle', 'rb'))
ts_df = pd.DataFrame(num_edges, columns=['Number of Edges'])
plot_util.plot_ts(ts_df, 'CHAOS', anomaly_time_steps, save_file_name='result/numEdgesPlot.png', xLabel='Time', yLabel='# of edges')

anomaly = cPickle.load(open('result/anomaly_sdne_100.pickle', 'rb'))
ts_df = pd.DataFrame(anomaly, columns=['Anomaly Scores'])
plot_util.plot_ts(ts_df, 'CHAOS', anomaly_time_steps, save_file_name='result/anomalyPlot.png', xLabel='Time', yLabel='Anomaly')
